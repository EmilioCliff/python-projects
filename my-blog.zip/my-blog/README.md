In this repo, the blog-post is an web application where I get to post my blogs and users can read them.
For a registered user can comment on the post and later on I'll be working on collaborators whoare able to add their blogs.
