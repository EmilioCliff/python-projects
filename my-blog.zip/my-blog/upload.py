# from main import Users, BlogPost
# new_user = Users(
#     email="add@gmail.com",
#     password="admin",
#     name="admin"
# )
# blog = BlogPost(

# )